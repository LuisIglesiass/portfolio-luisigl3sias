export const NotFound = () => {
    return (
        <div>
            <h1>NotFound</h1>
        </div>
    )
}